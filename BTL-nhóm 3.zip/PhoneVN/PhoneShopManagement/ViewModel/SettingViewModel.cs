﻿using ClothesShopManagement.Model;
using ClothesShopManagement.View;
using Microsoft.Win32;
using PhoneShopManagement.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ClothesShopManagement.ViewModel
{
    class SettingViewModel:BaseViewModel
    {
        private string _localLink = System.Reflection.Assembly.GetExecutingAssembly().Location.Remove(System.Reflection.Assembly.GetExecutingAssembly().Location.IndexOf(@"bin\Debug"));

        private BitmapImage _Ava;
        public BitmapImage Ava { get => _Ava; set { _Ava = value; OnPropertyChanged(); } }
        private string _Name;
        public string Name { get => _Name; set { _Name = value; OnPropertyChanged(); } }
        private string _DoB;
        public string DoB { get => _DoB; set { _DoB = value; OnPropertyChanged(); } }
        private string _DiaChi;
        public string DiaChi { get => _DiaChi; set { _DiaChi = value; OnPropertyChanged(); } }
        private string _Mail;
        public string Mail { get => _Mail; set { _Mail = value; OnPropertyChanged(); } }
        private int _GioiTinh;
        public int GioiTinh { get => _GioiTinh; set { _GioiTinh = value; OnPropertyChanged(); } }
        private string _SDT;
        public string SDT { get => _SDT; set { _SDT = value; OnPropertyChanged(); } }
        private string _TenTK;
        public string TenTK { get => _TenTK; set { _TenTK = value; OnPropertyChanged(); } }
        private NGUOIDUNG _User;
        public NGUOIDUNG User { get => _User; set { _User = value; OnPropertyChanged(); } }
        public ICommand Loadwd { get; set; }
        public ICommand UpdateInfo { get; set; }
        public ICommand AddImage { get; set; }
        public ICommand ChangePass { get; set; }
        public SettingViewModel()
        {
            Loadwd = new RelayCommand<SettingView>((p) => true, (p) => _Loadwd(p));
            AddImage = new RelayCommand<ImageBrush>((p) => true, (p) => _AddImage(p));
            UpdateInfo = new RelayCommand<SettingView>((p) => true, (p) => _UdpateInfo(p));
            ChangePass = new RelayCommand<SettingView>((p) => true, (p) => _ChangePass());
        }
        void _ChangePass()
        {
            ChangePassword change = new ChangePassword();
            change.ShowDialog();
        }
        void _AddImage(ImageBrush p)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.png)|*.jpg; *.png";
            if (open.ShowDialog() == true)
            {
                Ava = new BitmapImage(new Uri(open.FileName));
            }
            p.ImageSource = Ava;
        }
        void _Loadwd(SettingView p)
        {
            if (LoginViewModel.IsLogin)
            {
                string a = Const.TenDangNhap;
                User = DataProvider.Ins.DB.NGUOIDUNGs.Where(x => x.USERNAME == a).FirstOrDefault();
                string fileUrl = User.AVA.Contains(_localLink) ? User.AVA : (_localLink + User.AVA);
                //Ava = new BitmapImage(new Uri(fileUrl));
                Uri fileUri;


                if (Uri.TryCreate(fileUrl, UriKind.Absolute, out fileUri) && File.Exists(fileUrl))
                {
                    Ava = new BitmapImage(fileUri);
                }
                Name = User.TENND;
                DoB = User.NGSINH.ToString();
                DiaChi = User.DIACHI;
                GioiTinh = (User.GIOITINH == "Nam") ? 0 : 1;
                SDT = User.SDT;
                TenTK = User.USERNAME;
                Mail = User.MAIL;
            }
        }
        void _UdpateInfo(SettingView p)
        {
            foreach (NGUOIDUNG temp2 in DataProvider.Ins.DB.NGUOIDUNGs)
            {
                if (temp2.MAIL == p.Mail.Text&&p.Mail.Text!=Const.ND.MAIL)
                {
                    MessageBox.Show("Email này đã được sử dụng !", "THÔNG BÁO", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            string match = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
            Regex reg = new Regex(match);
            if (!reg.IsMatch(p.Mail.Text))
            {
                MessageBox.Show("Email không hợp lệ !", "THÔNG BÁO", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var temp = DataProvider.Ins.DB.NGUOIDUNGs.Where(pa => pa.USERNAME == TenTK).FirstOrDefault();
            temp.TENND = p.NameBox.Text;
            temp.SDT = p.SDTBox.Text;
            temp.DIACHI = p.AddressBox.Text;
            temp.GIOITINH = p.GTBox.Text;
            temp.NGSINH = (DateTime)p.DateBox.SelectedDate;
            temp.MAIL = p.Mail.Text;
            string rd = StringGenerator();
            if (!Ava.UriSource.AbsolutePath.Contains(User.AVA) )
                temp.AVA = "/Resource/" + rd + (Ava.UriSource.AbsolutePath.Contains(".jpg") ? ".jpg" : ".png").ToString();
            DataProvider.Ins.DB.SaveChanges();
            try
            {
                if (!Ava.ToString().Contains(User.AVA))
                    File.Copy(Ava.UriSource.AbsolutePath, Const._localLink + @"Resource/" + rd + (Ava.UriSource.AbsolutePath.Contains(".jpg") ? ".jpg" : ".png").ToString(), true);
            }
            catch (Exception e) {
            Console.WriteLine(e.ToString());
            }
            MessageBox.Show("Cập nhật thành công!", "Thông báo");
        }
        static string StringGenerator()
        {
            Random rd = new Random();
            int length = rd.Next(5, 20);
            StringBuilder str_build = new StringBuilder();
            Random random = new Random();
            char letter;
            for (int i = 0; i < length; i++)
            {
                double flt = random.NextDouble();
                int shift = Convert.ToInt32(Math.Floor(25 * flt));
                letter = Convert.ToChar(shift + 65);
                str_build.Append(letter);
            }
            return str_build.ToString();
        }
    }
}
